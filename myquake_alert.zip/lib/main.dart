import 'package:flutter/material.dart';

void main() {
  runApp(MyQuakeAlertApp());
}

class MyQuakeAlertApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'MyQuake Alert',
      theme: ThemeData(
        primarySwatch: Colors.red,
      ),
      home: Scaffold(
        appBar: AppBar(title: Text('MyQuake Alert')),
        body: Center(child: Text('Earthquake Alerts Coming Soon!')),
      ),
    );
  }
}
